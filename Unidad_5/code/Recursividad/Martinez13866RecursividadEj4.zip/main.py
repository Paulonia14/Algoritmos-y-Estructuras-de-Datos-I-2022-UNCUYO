from algo1 import *
from mylinkedlist import *

def move(L,posInicio,posFinal):
  #Ordena la lista ingresada de menor a mayor elemento
  #Caso base
  if posFinal==length(L)-1:
    return
  #Mover el current a la posición de destino
  current=L.head
  if posFinal!=0:
    for i in range (0,posFinal):
      current=current.nextNode
  #Buscar valor más chico
  menor=current.value
  position=posFinal
  for i in range(posFinal,length(L)):
    if current.value<=menor:
      menor=current.value
      posInicio=position
    position+=1
    current=current.nextNode
  #Mover un nodo de un lugar(posInicio) a otro(posFinal)
  element=access(L,posInicio)
  current=L.head
  if posFinal!=0:
    for i in range (0,posFinal):
      current=current.nextNode
  if (posInicio!=posFinal):
    for i in range (posFinal,posInicio-1):
      current=current.nextNode
    current.nextNode=current.nextNode.nextNode
    insert(L,element,posFinal)
  return move(L,posInicio,posFinal+1)


L=LinkedList

llenarLista(L)
printList(L)
move(L,0,0)
print("Lista ordenada de menor a mayor: ")
printList(L)