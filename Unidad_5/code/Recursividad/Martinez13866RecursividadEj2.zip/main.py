from algo1 import *

def suma(n):
  if n==1:
    return n
  return n+(suma(n-1))

check=False
while check==False:
  n=input_int("Ingrese un número entero positivo: ")
  if n>0:
    check=True
resultado=suma(n)
print(f"La suma de los primeros {n} números es: {resultado}")

