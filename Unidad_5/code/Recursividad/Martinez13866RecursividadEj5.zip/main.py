from algo1 import *
from mystack import *
from mylinkedlist import printList

def stack_fibonacci(num):
  S=LinkedList()
  push(S,0)
  push(S,1)
  resultado=0
  if num==1:
    return 1
  for i in range(0,num-1):
    aux1=pop(S)
    aux2=pop(S)
    resultado=aux1+aux2
    push(S,aux1)
    push(S,resultado)
  return resultado


check=False
while check==False:
  n=input_int("Ingrese un número entero positivo: ")
  if n>=0:
    check=True
print(f"El número {n} de Fibonacci es: {stack_fibonacci(n)}")


