from algo1 import *

def sumaPares(n):
  if n==2:
    return n
  elif n%2==0:
    return n+(sumaPares(n-2))
  else:
    return print("Error")
  
check=False
while check==False:
  n=input_int("Ingrese un número entero positivo: ")
  if n>0:
    check=True
resultado=sumaPares(n)
if n%2==0:
  print(f"La suma de los pares desde 2 hasta {n} es: {resultado}")

