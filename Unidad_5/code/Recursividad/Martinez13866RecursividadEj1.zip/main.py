from algo1 import *

def Fibonacci(n):
  if n==0 or n==1:
    return n
  return Fibonacci(n-1) + Fibonacci(n-2)
  
  
check=False
while check==False:
  n=input_int("Ingrese un número entero positivo: ")
  check=True
  if n<0:
    print("Debe ser un número positivo")
    check=False
print(f"Número {n} de Fibonacci: {Fibonacci(n)}")

