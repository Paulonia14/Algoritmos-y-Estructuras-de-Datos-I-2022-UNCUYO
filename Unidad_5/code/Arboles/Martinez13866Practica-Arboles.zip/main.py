from binarytree import *
import mylinkedlist 

# -- Ejercicio 1 --
def checkBalancedTree(B):
  #verifica si un árbol binario está balanceado (Retorna True si lo es, False si no)
  if B.root==None:
    return None
  else:
    check=True
    levelSub1=0;levelSub2=0
    if B.root.leftnode!=None:
      levelSub1=1
      levelSub1=checkBalance(B.root.leftnode,levelSub1)
    if B.root.rightnode!=None:
      levelSub2=1    
      levelSub2=checkBalance(B.root.rightnode,levelSub2)
    if levelSub1>levelSub2:
      if (levelSub1-levelSub2)>1:
        check=False
    else:
      if (levelSub2-levelSub1)>1:
        check=False
    return check
    
def checkBalance(current,level):
  level=checkLevelperHead(current,level)
  if current.leftnode!=None:
    level=checkBalance(current.leftnode,level)
  if current.rightnode!=None:
    level=checkBalance(current.rightnode,level)
  return level
  
def checkLevelperHead(current,level):
  #Verifica si un nodo tiene hijos a izq y derecha y suma los que tenga (solo los que sean sus hijos, no va a sumar los hijos de sus hijos)
  if current.leftnode!=None:
    level+=1
  if current.rightnode!=None:
    level+=1
  return level
 
# -- Ejercicio 2 --
def checkSubTree(B1,B2):
  #determina si B2 es un subárbol de B1 (Retorna True si lo es, False si no, y None si alguno de los árboles ingresados está vacío)
  #Primero verifico si el tamaño del árbol 1 es mayor al tamaño del árbol 2, luego si se ingresa algún arbol vacío
  L1=traverseBreadFirst(B1)
  L2=traverseBreadFirst(B2)
  if mylinkedlist.length(L1)<mylinkedlist.length(L2):
    print("Tamaños no válidos")
    return None
  elif B1.root==None or B2.root==None:
    return None
  else:
    check=False
    check=checkSubHead(B1.root,B2.root,check)
    return check
    
def checkSubHead(currentB1,currentB2,check):
  if currentB1!=None:
    #Encuentro donde empieza el subarbol B2, si su raiz no se encuentra en B1 delvuelve False
    if currentB1.key==currentB2.key:
      check=True
      check=checkSubTreeComplete(currentB1,currentB2,check)
      return check
    else:
      if currentB1.leftnode!=None:
        check=checkSubHead(currentB1.leftnode,currentB2,check)
      if currentB1.rightnode!=None:
        check=checkSubHead(currentB1.rightnode,currentB2,check)
  return check
  
def checkSubTreeComplete(currentB1,currentB2,check):
  #Verifico si los nodos son distintos
  if currentB1!=None and currentB2!=None:
    if currentB1.key!=currentB2.key:
      check=False
  #Checkeo si el segundo arbol tiene nodos de más por izquierda o derecha
  if currentB1.leftnode==None and currentB2.leftnode!=None:
    check=False
  elif currentB1.rightnode==None and currentB2.rightnode!=None:
    check=False
  #Checkeo si los dos arboles tienen nodos a la izquierda
  if currentB1.leftnode!=None and currentB2.leftnode!=None:
    check=checkSubTreeComplete(currentB1.leftnode,currentB2.leftnode,check)
  #Checkeo si los dos arboles tienen nodos a la derecha 
  if currentB1.rightnode!=None and currentB2.rightnode!=None:
    check=checkSubTreeComplete(currentB1.rightnode,currentB2.rightnode,check)
  return check

# -- Ejercicio 3 --
def checkBST(B):
  #verifica que un árbol binario es un Árbol Binario de Búsqueda (Retorna True si lo es, False si no)
  if B.root==None:
    return None
  checkBinary=True
  checkBinary=checkBTree(B.root,checkBinary)
  return checkBinary
def checkBTree(current,checkBinary):
  if current!=None:
    if current.leftnode!=None:
      if current.leftnode.key>=current.key:
        checkBinary=False
    if current.rightnode!=None:
      if current.rightnode.key<=current.key:
        checkBinary=False
    checkBinary=checkBTree(current.leftnode,checkBinary)
    checkBinary=checkBTree(current.rightnode,checkBinary)
  return checkBinary


B1=BinaryTree()
insert(B1,5,5);insert(B1,3,3);insert(B1,2,2);insert(B1,1,1)
insert(B1,7,7);insert(B1,6,6);insert(B1,4,4);insert(B1,9,9)

B2=BinaryTree()
insert(B2,5,5);insert(B2,3,3);insert(B2,7,7);insert(B2,6,6);insert(B2,9,9)

B3=BinaryTree()
insert(B3,8,8);insert(B3,4,4);insert(B3,2,2);insert(B3,5,5)
insert(B3,3,3);insert(B3,1,1);insert(B3,12,12);insert(B3,10,10)
insert(B3,14,14)

B4=BinaryTree()
insert(B4,3,3);insert(B4,2,2);insert(B4,1,1);insert(B4,5,5)

B5=BinaryTree()
insert(B5,5,5);insert(B5,3,3);insert(B5,2,2);insert(B5,1,1)
insert(B5,7,7);insert(B5,6,6);insert(B5,4,4);insert(B5,9,9);insert(B5,0,0);insert(B5,-1,-1)

B6=BinaryTree()
insert(B6,5,5);insert(B6,3,3);insert(B6,2,2);insert(B6,1,1)

B7=BinaryTree()
insert(B7,7,7);insert(B7,5,5);insert(B7,4,4);insert(B7,6,6);insert(B7,8,8);insert(B7,9,9)
insert(B7,10,10);insert(B7,14,14);insert(B7,3,3)

print("B1:")
L1=traverseBreadFirst(B1)
mylinkedlist.printList(L1)

print("B2:")
L2=traverseBreadFirst(B2)
mylinkedlist.printList(L2)

print("B3:")
L3=traverseBreadFirst(B3)
mylinkedlist.printList(L3)

print("B4:")
L4=traverseBreadFirst(B4)
mylinkedlist.printList(L4)

print("B5:")
L5=traverseBreadFirst(B5)
mylinkedlist.printList(L5)

print("B6:")
L6=traverseBreadFirst(B6)
mylinkedlist.printList(L6)

print("B7:")
L7=traverseBreadFirst(B7)
mylinkedlist.printList(L7)

print("")
print("Ej 1:")
a=checkBalancedTree(B1)
print("B1 balanceado: ",a)
aa=checkBalancedTree(B2)
print("B2 balanceado: ",aa)
aaa=checkBalancedTree(B3)
print("B3 balanceado: ",aaa)
aaaa=checkBalancedTree(B4)
print("B4 balanceado: ",aaaa)
aaaaa=checkBalancedTree(B5)
print("B5 balanceado: ",aaaaa)
aaaaaa=checkBalancedTree(B6)
print("B6 balanceado: ",aaaaaa)
aaaaaaa=checkBalancedTree(B7)
print("B7 balanceado: ",aaaaaa)

print("")
print("Ej 2: ")
b=checkSubTree(B1,B2)
print("B2 subarbol de B1: ",b)
b2=checkSubTree(B1,B4)
print("B4 subarbol de B1: ",b2)

print("")
print("Ej 3:")
c=checkBST(B1)
if c==False:
  print("El árbol no es árbol binario de búsqueda")
elif c==True:
  print("El árbol es un árbol binario de búsqueda")
else:
  print("El árbol está vacío")