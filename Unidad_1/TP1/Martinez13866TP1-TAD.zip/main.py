from algo1 import *
from set import *
import random
from vectores_y_matrices import *

#llena los vectores con valores random del 1 al 9 (incluidos)
def llenarvec_random(vector,n):
  for i in range(0,n):
    vector[i]=random.randint(1,9)
  return vector


bandera=False
while(bandera==False):
  dimension1=input_int("Ingrese la dimensión del vector 1: ")
  dimension2=input_int("Ingrese la dimensión del vector 2: ")
  if (dimension1<=0) or (dimension2<=0):
    print("Dimensiones inválidas")
  else:
    bandera=True

vectorS=Array(dimension1,0)
vectorT=Array(dimension2,0)
vectorS=llenarvec_random(vectorS,dimension1)
vectorT=llenarvec_random(vectorT,dimension2)
mostrar_vector(vectorS,dimension1)
mostrar_vector(vectorT,dimension2)

#Para probar las distintas operaciones (sin create_set):
print("Operaciones en los vectores: ")
duplicadosS=check_duplicates(vectorS)
duplicadosT=check_duplicates(vectorT)
if (duplicadosS==False) and (duplicadosT==False):
  print("Unión:")
  vectorR=Union(vectorS,vectorT)
  mostrar_vector(vectorR,len(vectorR))
  print("Intersección:")
  vectorR=Intersection(vectorS,vectorT)
  mostrar_vector(vectorR,len(vectorR))
  print("Diferencia:")
  vectorR=Difference(vectorS,vectorT)
  mostrar_vector(vectorR,len(vectorR))
else:
  print("No se puede realizar operaciones, los array tienen valores repetidos")
  print("Vamos a sacarle los valores repetidos para realizar operaciones")
  #Se muestra los vectores sin repetidos
  print("Array 1 sin repetidos:")
  nuevoS=Create_Set(vectorS)
  mostrar_vector(nuevoS,len(nuevoS))
  print("Array 2 sin repetidos:")
  nuevoT=Create_Set(vectorT)
  mostrar_vector(nuevoT,len(nuevoT))
  #Para probar las distintas operaciones (con create_set):
  print("Unión:")
  nuevoR=Union(nuevoS,nuevoT)
  mostrar_vector(nuevoR,len(nuevoR))
  print("Intersección:")
  nuevoR=Intersection(nuevoS,nuevoT)
  mostrar_vector(nuevoR,len(nuevoR))
  print("Diferencia:")
  nuevoR=Difference(nuevoS,nuevoT)
  mostrar_vector(nuevoR,len(nuevoR))

