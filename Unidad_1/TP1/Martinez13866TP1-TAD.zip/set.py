import algo1

def check_duplicates(Array):
  duplicado=False
  for i in range(0,len(Array)):
    for j in range(0,len(Array)):
      if (Array[i]==Array[j]) and (i!=j):
        duplicado=True
    return duplicado

def Create_Set(Array):
  #busca los elementos repetidos del array y los elimina cambiando por None
  for i in range(0,len(Array)):
    for j in range(0,len(Array)):
      if (Array[i]==Array[j]) and (i!=j):
        Array[j]=None
  #cuenta la cantidad de elementos repetidos para sacar la dimension del nuevo array
  contadorDup=0
  for i in range(0,len(Array)):
    if Array[i]==None:
      contadorDup+=1
  n=len(Array)-contadorDup
  ArrayR=algo1.Array(n,0)
  #se llena el nuevo array ignorando los elementos None del array anterior
  cont=0
  for i in range(0,len(Array)):
    if(Array[i]!=None):
      ArrayR[cont]=Array[i]
      cont+=1
  return ArrayR
  
def Union(ArrayS,ArrayT):
  duplicados=check_duplicates(ArrayS)
  duplicados2=check_duplicates(ArrayT)
  if (duplicados==True) or (duplicados2==True):
    print("No es posible realizar la operación de unión")
    return
  ArrayR=algo1.Array(len(ArrayS)+len(ArrayT),0)
  for i in range(0,len(ArrayS)):
    ArrayR[i]=ArrayS[i]
  for i in range(0,len(ArrayT)):
    ArrayR[i+len(ArrayS)]=ArrayT[i]
  #Se devuelve el array resultado sin elementos repetidos
  ArrayR=Create_Set(ArrayR)
  return ArrayR

def Intersection(ArrayS,ArrayT):
  duplicados=check_duplicates(ArrayS)
  duplicados2=check_duplicates(ArrayT)
  if (duplicados==True) or (duplicados2==True):
    print("No es posible realizar la operación de intersección")
    return
  ArrayR=algo1.Array(len(ArrayS)+len(ArrayT),0)
  cont=0
  for i in range(0,len(ArrayS)):
    for j in range(0,len(ArrayT)):
      if ArrayS[i]==ArrayT[j]:
        ArrayR[cont]=ArrayS[i]
        cont+=1
  ArrayR=Create_Set(ArrayR)
  return ArrayR

def Difference(ArrayS,ArrayT):
  duplicados=check_duplicates(ArrayS)
  duplicados2=check_duplicates(ArrayT)
  if (duplicados==True) or (duplicados2==True):
    print("No es posible realizar la operación de diferencia")
    return
  ArrayR=algo1.Array(len(ArrayS)+len(ArrayT),0)
  cont=0
  for i in range(0,len(ArrayS)):
    igual=False
    for j in range(0,len(ArrayT)):
      if ArrayS[i]==ArrayT[j]:
        igual=True
    if igual==False:
      ArrayR[cont]=ArrayS[i]
      cont+=1
  ArrayR=Create_Set(ArrayR)
  return ArrayR

  