from algo1 import *
import math

def leer_vector(vector,n):
  for i in range(0,n):
    vector[i]=input_real(f"Ingrese el elemento {i} del vector: ")
  return vector

def sumar_vectores(vector1,vector2,n):
  vector3=Array(n,0.0)
  for i in range(0,n):
    vector3[i]=vector1[i]+vector2[i]
  return vector3

def mostrar_vector(vector,n):
  for i in range(0,n):
    if (i==0):
      print("[",vector[i],end="; ")
    elif(i==n-1):
      print(vector[i],"]",end=" ")
    else:
      print(vector[i],end="; ")
  print(" ")
      
def norma_cuadratica(vector,n):
  suma=0
  for i in range(0,n):
    suma+=math.pow(vector[i],2)
  suma=math.sqrt(suma)
  return suma

bandera=False

while (bandera==False):
  dimension1=input_int("Ingrese el tamaño del vector 1: ")
  dimension2=input_int("Ingrese el tamaño del vector 2: ")
  if (dimension1<=1) or (dimension2<=1):
    print("Las dimensiones de los vectores deben ser mayor a 1")
  else:
    if (dimension1==dimension2):
      bandera=True
    else:
      print("Las dimensiones de los vectores deben ser iguales")
  
vector1=Array(dimension1,0.0)
vector2=Array(dimension1,0.0)

print("A continuación, ingrese los elementos del vector 1: ")
vector1=leer_vector(vector1,dimension1)
print("A continuación, ingrese los elementos del vector 2: ")
vector2=leer_vector(vector2,dimension1)

vectorSuma= sumar_vectores(vector1,vector2,dimension1)
norma=norma_cuadratica(vectorSuma,dimension1)

print("El vector resultado de la suma de los 2 vectores es:")
mostrar_vector(vectorSuma,dimension1)
print("La norma cuadrática del vector suma es: ",round(norma))