from algo1 import *
from vectores_y_matrices import *

def multiplicacion(vector,matriz,n,m,resultado):
  for i in range(0,n):
    res=0
    for j in range(0,m):
      res+= vector[j] * matriz[i][j]
      resultado[i]=res
  return resultado

bandera=False

while(bandera==False):
  dimensionV=input_int("Ingrese la dimension del vector: ")
  filasM=input_int("Ingrese la cantidad de filas de la matriz: ")
  columnasM=input_int("Ingrese la cantidad de columnas de la matriz: ")
  if (dimensionV<=1) or (filasM<=1) or (columnasM<=1):
    print("Las dimensiones deben ser mayor a 1")
  else:
    if (dimensionV!=columnasM):
      print("Dimensiones incorrectas")
    else:
      bandera=True
  
vector=Array(dimensionV,0.0)
matriz=Array(filasM,Array(columnasM,0.0))
vectorR=Array(columnasM,0.0)

#Se llenan y muestran el vector y la matriz segun lo que ingrese el usuario
leer_vector(vector,dimensionV)
mostrar_vector(vector,dimensionV)
leer_matriz(matriz,filasM,columnasM)
mostrar_matriz(matriz,filasM,columnasM)

vectorR=multiplicacion(vector,matriz,filasM,columnasM,vectorR)
print("La multiplicación da como resultado: ")
mostrar_vector(vectorR,columnasM)

