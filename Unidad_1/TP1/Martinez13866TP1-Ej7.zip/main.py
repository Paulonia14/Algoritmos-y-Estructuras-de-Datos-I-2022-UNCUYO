from algo1 import *
from vectores_y_matrices import *

def multiplicacion(matriz1,matriz2,filas1,columnas2):
  resultado=Array(filas1,Array(columnas2,0.0))
  filas2=len(matriz2)
  for i in range(filas1):
    for j in range(columnas2):
      for k in range(filas2):
        resultado[i][j]+=matriz1[i][k]*matriz2[k][j]
  return resultado

bandera=False
while(bandera==False):
  filasA=input_int("Ingrese la cantidad de filas de la matriz A: ")
  columnasA=input_int("Ingrese la cantidad de columnas de la matriz A: ")
  if(filasA<=1 or columnasA<=1):
    print("Dimensiones inválidas")
  else:
    filasB=input_int("Ingrese la cantidad de filas de la matriz B: ")
    columnasB=input_int("Ingrese la cantidad de columnas de la matriz B: ")
    if (filasB<=1 or columnasB<=1):
      print("Dimensiones inválidas")
    else:
      if(columnasA!=filasB):
        print("La cantidad de columnas de la matriz A debe ser igual a la cantidad de filas de matriz B")
      else:
        bandera=True

matrizA=Array(filasA,Array(columnasA,0.0))
matrizB=Array(filasB,Array(columnasB,0.0))
leer_matriz(matrizA,filasA,columnasA)
mostrar_matriz(matrizA,filasA,columnasA)
leer_matriz(matrizB,filasB,columnasB)
mostrar_matriz(matrizB,filasB,columnasB)

matrizR=multiplicacion(matrizA,matrizB,filasA,columnasB)
print("Las matrices multiplicadas da como resultado: ")
mostrar_matriz(matrizR,filasA,columnasB)