from algo1 import *
from vectores_y_matrices import *

def prod_escalar(vector1,vector2,n):
  resultado=0
  for i in range(0,n):
    resultado+=vector1[i]*vector2[i]
  return resultado

bandera=False
while(bandera==False):
  dimension1=input_int("Ingrese la dimension del vector 1: ")
  dimension2=input_int("Ingrese la dimension del vector 2: ")
  if dimension1<=0 or dimension2<=0:
    print("Las dimensiones deben ser mayor a 0")
  else:
    if dimension1!=dimension2:
      print("Las dimensiones deben ser iguales")
    else:
      bandera=True
      
vector1=Array(dimension1,0.0)
vector2=Array(dimension1,0.0)
leer_vector(vector1,dimension1)
leer_vector(vector2,dimension1)
mostrar_vector(vector1,dimension1)
mostrar_vector(vector2,dimension1)

prodEscalar=prod_escalar(vector1,vector2,dimension1)
print("El producto escalar entre los 2 vectores es: ",prodEscalar)

