from algo1 import *

def calcular_mayor(vector,longitud,menor):
  for i in range(0,longitud):
    if (abs(vector[i])>menor):
      mayor=abs(vector[i])
  return mayor
  
longitud=input_int("Ingrese la longitud del vector deseado: ")
vector=Array(longitud,0)
menor=0

print("A continuación, ingrese los elementos del vector")
for i in range(0,longitud):
  vector[i]=input_int("")
  menor=menor-vector[i]

mayor=calcular_mayor(vector,longitud,menor)
print("El mayor elemento del vector es: ",mayor)

