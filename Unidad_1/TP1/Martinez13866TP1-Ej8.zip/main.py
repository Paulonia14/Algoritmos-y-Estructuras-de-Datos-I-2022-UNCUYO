from algo1 import *
from vectores_y_matrices import *

def triangular_inferior(matriz,n,m):
  triangular=False
  for i in range(0,n):
    for j in range(0,m):
      if i<j:
        if matriz[i][j]==0:
          triangular=True
        else:
          triangular=False
          return triangular
  return triangular

def matriz_traspuesta(matriz):
  filas=len(matriz)
  columnas=len(matriz[0])
  matrizT=Array(columnas,Array(filas,0.0))
  for i in range(0,columnas):
    for j in range(0,filas):
      matrizT[i][j]=matriz[j][i]
  return matrizT
  
bandera=False
while(bandera==False):
  filas=input_int("Ingrese las filas de la matriz: ")
  columnas=input_int("Ingrese las columnas de la matriz: ")
  if (filas<=0) or (columnas<=0):
    print("Dimensiones inválidas")
  else:
    bandera=True

matriz=Array(filas,Array(columnas,0.0))
leer_matriz(matriz,filas,columnas)
mostrar_matriz(matriz,filas,columnas)

triangularInf=triangular_inferior(matriz,filas,columnas)
if triangularInf==True:
  print("La matriz es triangular inferior")
  print("Su traspuesta es:")
  matrizT=matriz_traspuesta(matriz)
  mostrar_matriz(matrizT,columnas,filas)
else:
  print("La matriz NO es triangular inferior")
  
