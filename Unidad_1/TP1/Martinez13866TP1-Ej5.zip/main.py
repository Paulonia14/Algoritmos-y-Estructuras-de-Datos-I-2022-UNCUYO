from algo1 import *
from vectores_y_matrices import *

def triangular_superior(matriz,n,m):
  triangular=False
  for i in range(0,n):
    for j in range(0,m):
      if i>j:
        if matriz[i][j]==0:
          triangular=True
        else:
          triangular=False
          return triangular
  return triangular

def determinante(matriz,n,m):
  resultado=1
  for i in range(0,n):
    for j in range(0,m):
      #diagonal principal
      if(i==j):
        resultado=matriz[i][j]*resultado
  return resultado

bandera=False
while (bandera==False):
  filas=input_int("Ingrese las filas de la matriz: ")
  columnas=input_int("Ingrese las columnas de la matriz: ")
  if filas<=0 or columnas<=0:
    print("Las dimensiones deben ser mayor a 0")
  else:
    if filas!=columnas:
      print("La matriz debe ser cuadrada (dimensiones iguales)")
    else:
      bandera=True

matriz=Array(filas,Array(columnas,0.0))
leer_matriz(matriz,filas,columnas)
mostrar_matriz(matriz,filas,columnas)
triangular=triangular_superior(matriz,filas,columnas)

if triangular==True:
  print("La matriz es triangular superior")
  det=determinante(matriz,filas,columnas)
  print("El determinante de la matriz es: ",det)
else:
  print("La matriz NO es triangular superior")

