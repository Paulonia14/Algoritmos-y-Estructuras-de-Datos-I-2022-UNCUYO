from algo1 import *

def leer_vector(vector,n):
  for i in range(0,n):
    vector[i]=input_real(f"Ingrese el elemento {i} del vector: ")
  return vector

def mostrar_vector(vector,n):
  if n==1:
    print(f"[ {vector[0]} ]")
  else:
    for i in range(0,n):
      if (i==0):
        print("[",vector[i],end="; ")
      elif(i==n-1):
        print(vector[i],"]",end=" ")
      else:
        print(vector[i],end="; ")
    print(" ")

def leer_matriz(matriz,n,m):
  for i in range(0,n):
    for j in range(0,m):
      matriz[i][j]=input_real(f"Ingrese el elemento ({i}, {j}) de la matriz: ")
  return matriz

def mostrar_matriz(matriz,n,m):
  for i in range(0,n):
    print(end="|")
    for j in range(0,m):
      if (j!=m-1):
        print(matriz[i][j],end="; ")
      else:
        print(matriz[i][j],end="")
    print(end="|")
    print(" ")
  print(" ")
