from algo1 import *
from vectores_y_matrices import *

def resta_matrices(matriz1,matriz2,resultado,n,m):
  for i in range(0,filas):
    for j in range(0,columnas):
      resultado[i][j]= matriz1[i][j] - matriz2[i][j]
  return resultado

bandera=False
while (bandera==False):
  filas=input_int("Ingrese la cantidad de filas de las 2 matrices: ")
  columnas=input_int("Ingrese la cantidad de columnas de las 2 matrices: ")
  if filas<=0 or columnas<=0:
    print("Las dimensiones deben ser mayor a 0")
  else:
    bandera=True

matriz1=Array(filas,Array(columnas,0.0))
matriz2=Array(filas,Array(columnas,0.0))
matrizR=Array(filas,Array(columnas,0.0))

print("A continuación, ingrese la primera matriz:")
leer_matriz(matriz1,filas,columnas)
mostrar_matriz(matriz1,filas,columnas)
print("Ahora llene la segunda matriz:")
leer_matriz(matriz2,filas,columnas)
mostrar_matriz(matriz2,filas,columnas)

matrizR=resta_matrices(matriz1,matriz2,matrizR,filas,columnas)
print("La resta de las 2 matrices ingresadas es igual a:")
mostrar_matriz(matrizR,filas,columnas)

